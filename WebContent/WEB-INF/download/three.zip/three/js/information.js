$(function() {
	document.body.addEventListener('touchstart', function () {});	
	var list = $("input:text");
	var cou = 0;
	for (var j = 0; j < list.length; j++) {
		var id = list.eq(j).prop("id");
		var value = $("#" + id).val();
		console.log(value)
		if (value.length <= 0) {
			$("#" + id).focus();
			break;
		} else {
			cou++;
		}
	}
	$("input:text").on("blur keyup",function() {
		var c1 = 0;
		for (var j = 0; j < list.length; j++) {
			var id = list.eq(j).prop("id");
			var value = $("#" + id).val();
			if (value.length > 0) {
				c1++;
			}
		}
		if (c1 == list.length) {
			$("#submitBtn").removeClass("btn_normal").addClass("btn_down");
		} else {
			$("#submitBtn").addClass("btn_normal").removeClass("btn_down");
		}
	})
});